package coe528.project;

public abstract class CustomerLevel {
    public abstract double charge();
    public abstract void changeLevel(Customer c);
}
