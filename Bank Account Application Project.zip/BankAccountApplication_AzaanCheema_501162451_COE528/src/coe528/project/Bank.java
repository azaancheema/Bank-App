package coe528.project;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;

public class Bank extends Application {

    private final String managerUser = "admin";
    private final String managerPass = "admin";
    private ArrayList<Customer> customers = new ArrayList<>();

    @Override
    public void start(Stage primaryStage) {

        Button loginButton = new Button("Login");
        Button exitButton = new Button("Exit");
        Button signUpButton = new Button("Sign Up");

        Label usernameLabel = new Label("Username:");
        TextField usernameInput = new TextField();
        Label passwordLabel = new Label("Password:");
        TextField passwordInput = new TextField();
        Label roleLabel = new Label("Role:");
        TextField roleInput = new TextField();

        GridPane root = new GridPane();
        root.setPadding(new Insets(10));
        root.setVgap(8);
        root.setHgap(8);

        // Set background color for login screen
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));

        root.add(usernameLabel, 0, 0);
        root.add(usernameInput, 1, 0);
        root.add(passwordLabel, 0, 1);
        root.add(passwordInput, 1, 1);
        root.add(roleLabel, 0, 2);
        root.add(roleInput, 1, 2);

        root.add(loginButton, 0, 3);
        root.add(signUpButton, 1, 3);
        root.add(exitButton, 0, 4);

        Scene scene = new Scene(root, 350, 200);
        primaryStage.setTitle("Bank Login");
        primaryStage.setScene(scene);
        primaryStage.show();

        exitButton.setOnAction(e -> Platform.exit());

        signUpButton.setOnAction(e -> {
            String username = usernameInput.getText();
            String password = passwordInput.getText();
            if(username.isEmpty() || password.isEmpty()) {
                showAlert("Enter username and password", "Error");
                return;
            }
            for(Customer c: customers) {
                if(c.getUsername().equals(username)) {
                    showAlert("Username already exists", "Error");
                    return;
                }
            }
            customers.add(new CustomerImpl(username, password));
            showAlert("Account created. You can now log in.", "Success");
        });

        loginButton.setOnAction(e -> {
            String username = usernameInput.getText();
            String password = passwordInput.getText();
            String role = roleInput.getText();

            if(role.equalsIgnoreCase("Manager")) {
                if(username.equals(managerUser) && password.equals(managerPass)) {
                    showAlert("Welcome Manager!", "Login Successful");
                    managerDashboardWindow();
                } else {
                    showAlert("Invalid Manager credentials", "Error");
                }
            } else if(role.equalsIgnoreCase("Customer")) {
                Customer loggedInCustomer = null;
                for(Customer c : customers) {
                    if(c.getUsername().equals(username) && c.getPassword().equals(password)) {
                        loggedInCustomer = c;
                        break;
                    }
                }
                if(loggedInCustomer != null) {
                    loggedInCustomer.changeLevel();
                    showAlert("Welcome " + username + "!\nBalance: $" +
                            loggedInCustomer.getAmount() + "\nLevel: " +
                            loggedInCustomer.getLevelName(), "Login Successful");
                    customerAccountWindow(loggedInCustomer);
                } else {
                    showAlert("Customer does not exist or wrong password", "Error");
                }
            } else {
                showAlert("Invalid role", "Error");
            }
        });
    }

    private void showAlert(String message, String title) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void customerAccountWindow(Customer customer) {
        Stage stage = new Stage();
        stage.setTitle(customer.getUsername() + "'s Account");

        Label balanceLabel = new Label("Balance: $" + customer.getAmount());
        Label levelLabel = new Label("Level: " + customer.getLevelName());
        Label amountLabel = new Label("Amount:");
        TextField amountInput = new TextField();
        Button depositButton = new Button("Deposit");
        Button withdrawButton = new Button("Withdraw");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(8);
        grid.setHgap(8);

      

        grid.add(balanceLabel, 0, 0);
        grid.add(levelLabel, 0, 1);
        grid.add(amountLabel, 0, 2);
        grid.add(amountInput, 1, 2);
        grid.add(depositButton, 0, 3);
        grid.add(withdrawButton, 1, 3);

        depositButton.setOnAction(e -> {
            double amt = Double.parseDouble(amountInput.getText());
            customer.deposit(amt);
            balanceLabel.setText("Balance: $" + customer.getAmount());
            levelLabel.setText("Level: " + customer.getLevelName());
            amountInput.clear();
        });

        withdrawButton.setOnAction(e -> {
           String input = amountInput.getText().trim(); 
            if (input.isEmpty()) {
            showAlert("Please enter an amount to withdraw.", "Error");
            return;
        }
    
            double amt = Double.parseDouble(input); 
            if (!customer.verifyBalance(amt)) {
            showAlert("Not enough balance!", "Error");
            return;
        }

            customer.withdraw(amt);
            balanceLabel.setText("Balance: $" + customer.getAmount());
            levelLabel.setText("Level: " + customer.getLevelName());
            amountInput.clear();
        });

        Scene scene = new Scene(grid, 350, 200);
        stage.setScene(scene);
        stage.show();
    }

    private void managerDashboardWindow() {
        Stage stage = new Stage();
        stage.setTitle("Manager Dashboard");

        Label addUserLabel = new Label("New Customer Username: ");
        TextField addUserInput = new TextField();
        Label addPassLabel = new Label("Password: ");
        TextField addPassInput = new TextField();
        Button addButton = new Button("Add Customer");

        Label deleteUserLabel = new Label("Delete Customer Username: ");
        TextField deleteUserInput = new TextField();
        Button deleteButton = new Button("Delete Customer");

        Label viewLabel = new Label("Customers:");
        TextArea customerList = new TextArea();
        customerList.setEditable(false);
        updateCustomerList(customerList);

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(8);
        grid.setHgap(8);

        // Background color for manager dashboard
        grid.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));

        grid.add(addUserLabel, 0, 0);
        grid.add(addUserInput, 1, 0);
        grid.add(addPassLabel, 0, 1);
        grid.add(addPassInput, 1, 1);
        grid.add(addButton, 1, 2);

        grid.add(deleteUserLabel, 0, 3);
        grid.add(deleteUserInput, 1, 3);
        grid.add(deleteButton, 1, 4);

        grid.add(viewLabel, 0, 5);
        grid.add(customerList, 0, 6, 2, 1);

        addButton.setOnAction(e -> {
            String newUser = addUserInput.getText();
            String newPass = addPassInput.getText();
            if(newUser.isEmpty() || newPass.isEmpty()) {
                showAlert("Enter username and password", "Error");
                return;
            }
            for(Customer c : customers) {
                if(c.getUsername().equals(newUser)) {
                    showAlert("Username already exists", "Error");
                    return;
                }
            }
            customers.add(new CustomerImpl(newUser, newPass));
            updateCustomerList(customerList);
            showAlert("Customer added successfully", "Success");
            addUserInput.clear();
            addPassInput.clear();
        });

        deleteButton.setOnAction(e -> {
            String delUser = deleteUserInput.getText();
            Customer toRemove = null;
            for(Customer c : customers) {
                if(c.getUsername().equals(delUser)) {
                    toRemove = c;
                    break;
                }
            }
            if(toRemove != null) {
                customers.remove(toRemove);
                updateCustomerList(customerList);
                showAlert("Customer deleted successfully", "Success");
            } else {
                showAlert("Customer not found", "Error");
            }
            deleteUserInput.clear();
        });

        Scene scene = new Scene(grid, 400, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void updateCustomerList(TextArea area) {
        StringBuilder sb = new StringBuilder();
        for(Customer c : customers) {
            sb.append("Username: ").append(c.getUsername())
              .append(", Balance: $").append(c.getAmount())
              .append(", Level: ").append(c.getLevelName())
              .append("\n");
        }
        area.setText(sb.toString());
    }

    private static class CustomerImpl extends Customer {
        public CustomerImpl(String username, String password) {
            super(username, password);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
