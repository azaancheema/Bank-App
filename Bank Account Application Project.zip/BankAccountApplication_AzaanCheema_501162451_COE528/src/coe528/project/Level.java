package coe528.project;

public abstract class Level {
    public abstract double charge();

    public abstract void changeLevel(Customer c);
}
