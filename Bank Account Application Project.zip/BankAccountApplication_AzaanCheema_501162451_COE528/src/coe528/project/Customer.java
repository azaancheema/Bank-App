package coe528.project;

// Abstract Customer class
public abstract class Customer {
    protected String user; // Changed to protected so subclasses can access
    protected String pass; // Changed to protected
    protected double amount;
    protected CustomerLevel level;

    public Customer(String username, String password) {
        this.user = username;
        this.pass = password;
        this.amount = 100.0; // Default starting balance
        this.level = new Silver(); // Default level
    }

    public void setLevel(CustomerLevel customerLevel) {
        this.level = customerLevel;
    }

    public void changeLevel() {
        this.level.changeLevel(this);
    }

    // Deposit money
    public double deposit(double deposit) {
        amount += deposit;
        changeLevel();
        return amount;
    }

    // Withdraw money
    public double withdraw(double withdrawal) {
        amount -= withdrawal;
        changeLevel();
        return amount;
    }

    // Check if enough balance exists
    public boolean verifyBalance(double balance) {
        return amount >= balance;
    }

    public double getAmount() {
        return amount;
    }

    // Charge based on current level
    public double getCharge() {
        changeLevel();
        return level.charge();
    }

    // Getter methods for Bank.java
    public String getUsername() {
        return user;
    }

    public String getPassword() {
        return pass;
    }

    public String getLevelName() {
        return level.getClass().getSimpleName();
    }
}
