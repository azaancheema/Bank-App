package coe528.project;

public class Gold extends CustomerLevel {
    private double charge = 20; // Fee for Gold level

    @Override
    public double charge() {
        return charge;
    }

    @Override
    public void changeLevel(Customer c) {
        if (c.getAmount() < 10000) {
            c.setLevel(new Silver());
        } else if (c.getAmount() <= 20000) {
            c.setLevel(new Gold());
        } else {
            c.setLevel(new Platinum());
        }
    }
}
