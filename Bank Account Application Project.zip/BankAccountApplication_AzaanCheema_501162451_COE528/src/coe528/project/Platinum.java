package coe528.project;

public class Platinum extends CustomerLevel {
    private double charge = 0; // Fee for Platinum level

    @Override
    public double charge() {
        return charge;
    }

    @Override
    public void changeLevel(Customer c) {
        if (c.getAmount() < 10000) {
            c.setLevel(new Silver());
        } else if (c.getAmount() <= 20000) {
            c.setLevel(new Gold());
        } else {
            c.setLevel(new Platinum());
        }
    }
}
